var notebookArray = ['finemapping', 'orientation']
var notebookDict = {'Overview-1': 'finemapping', 'Bioinformatics-workflow-exercise:-SoS-and-linear-mixed-model-1': 'orientation'}
var notebookArrayMap = {'finemapping': 'Overview', 'orientation': 'Bioinformatics workflow ... mixed model'}
var workflowArray = ['LMM']
var workflowDict = {'LMM-GLMM-analyses-for-UK-Biobank-data-1': 'LMM'}
var workflowArrayMap = {'LMM': 'LMM/GLMM analyses for UK Biobank data'}